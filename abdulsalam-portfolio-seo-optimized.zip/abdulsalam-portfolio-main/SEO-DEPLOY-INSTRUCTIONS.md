# Abdul Salam Portfolio — SEO update

## What changed
- Improved homepage title and meta description for the real portfolio content.
- Added canonical URL, robots directives, Open Graph and Twitter sharing metadata.
- Added Person JSON-LD structured data using the portfolio URL and existing GitHub profile.
- Added `robots.txt` and `sitemap.xml`.
- Kept the existing design, styles, JavaScript, projects and assets intact.
- Kept the existing Google Search Console verification token.

## Deploy
1. Extract this ZIP.
2. Replace the files in your GitHub repository with the contents of `abdulsalam-portfolio-main`.
3. Commit and push to the branch connected to Vercel.
4. After deployment, open:
   - https://abdulsalam-portfolio-v295.vercel.app/robots.txt
   - https://abdulsalam-portfolio-v295.vercel.app/sitemap.xml
5. In Google Search Console, inspect the homepage and request indexing. Submit the sitemap URL `https://abdulsalam-portfolio-v295.vercel.app/sitemap.xml`.

## Before publishing
- Confirm the public GitHub profile URL in JSON-LD is yours.
- Add your real LinkedIn profile URL to `sameAs` only when you have the exact public profile URL.
- Check all project live-demo links; this SEO update does not validate third-party project demos.
- Google ranking is not guaranteed. Indexing and ranking depend on Google's crawling, content quality, relevance, competition and other signals.
